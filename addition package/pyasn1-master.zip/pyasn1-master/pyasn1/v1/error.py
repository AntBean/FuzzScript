class PyAsn1Error(StandardError): pass
class ValueConstraintError(PyAsn1Error): pass
class SubstrateUnderrunError(PyAsn1Error): pass
